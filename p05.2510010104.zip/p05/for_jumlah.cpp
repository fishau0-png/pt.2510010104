
#include <iostream>
using namespace std;

int main() {
    int jumlah = 0;

    cout << "Berapa nilai yang akan dimasukkan? ";
    cin >> jumlah;

    // Akumulator total
    double total = 0;

    // Akumulator banyak siswa yang lulus
    int banyak_lulus = 0;

    // Cegah pembagian dengan nol
    if (jumlah > 0) {

        for (int i = 1; i <= jumlah; i++) {
            double nilai = 0;

            cout << "Nilai ke-" << i << ": ";
            cin >> nilai;

            // Langkah 1 dan 2: menghitung total
            total += nilai;

            // Langkah 4: menghitung nilai yang lulus
            if (nilai >= 60) {
                banyak_lulus++;
            }
        }

        // Cetak hasil setelah perulangan selesai
        cout << "\nTotal nilai       : " << total << '\n';
        cout << "Rata-rata         : " << total / jumlah << '\n';
        cout << "Banyak yang lulus : " << banyak_lulus << '\n';

    } else {
        // Langkah 3: jika jumlah = 0
        cout << "Jumlah nilai harus lebih dari 0 "
             << "untuk menghitung rata-rata.\n";
    }

    return 0;
}
