
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {
    int jumlah_mahasiswa = 0;

    cout << "=== SiNilai v0.4 ===\n";

    // TODO 1: Input jumlah mahasiswa minimal 1
    do {
        cout << "Jumlah mahasiswa (minimal 1): ";
        cin >> jumlah_mahasiswa;
    } while (jumlah_mahasiswa < 1);

    // TODO 2: Akumulator di luar perulangan
    double total_nilai = 0;
    int jumlah_lulus = 0;

    cout << fixed << setprecision(3);

    // TODO 3: Perulangan untuk setiap mahasiswa
    for (int i = 1; i <= jumlah_mahasiswa; i++) {
        string nama;
        double k1, k2, k3, k4;
        double nilai_akhir;
        bool lulus;
        string huruf;

        cout << "\nMahasiswa ke-" << i << "\n";
        cout << "Nama: ";
        cin >> ws;
        getline(cin, nama);

        cout << "Nilai komponen 1: ";
        cin >> k1;
        cout << "Nilai komponen 2: ";
        cin >> k2;
        cout << "Nilai komponen 3: ";
        cin >> k3;
        cout << "Nilai komponen 4: ";
        cin >> k4;

        // Bobot disesuaikan dengan tabel contoh modul
        nilai_akhir = k1 * 0.10
                    + k2 * 0.45
                    + k3 * 0.25
                    + k4 * 0.20;

        // Status kelulusan
        lulus = nilai_akhir >= 60;

        // TODO 4: Akumulator nilai dan jumlah lulus
        total_nilai += nilai_akhir;

        if (lulus) {
            jumlah_lulus++;
        }

        // Kategori huruf agar sesuai contoh tabel
        if (nilai_akhir >= 80) {
            huruf = "A";
        } else if (nilai_akhir >= 75) {
            huruf = "B";
        } else if (nilai_akhir >= 65) {
            huruf = "C+";
        } else if (nilai_akhir >= 60) {
            huruf = "C";
        } else if (nilai_akhir >= 45) {
            huruf = "D";
        } else {
            huruf = "E";
        }

        // Kartu nilai mahasiswa
        cout << "\n--- Kartu Nilai ---\n";
        cout << "Nama        : " << nama << "\n";
        cout << "Nilai akhir : " << nilai_akhir << "\n";
        cout << "Huruf       : " << huruf << "\n";
        cout << "Status      : "
             << (lulus ? "Lulus" : "Belum lulus") << "\n";
    }

    // TODO 5: Rekap kelas setelah perulangan
    cout << "\n=== Rekap Kelas ===\n";
    cout << "Jumlah Mahasiswa : "
         << jumlah_mahasiswa << "\n";
    cout << "Lulus            : "
         << jumlah_lulus << "\n";
    cout << "Belum lulus      : "
         << jumlah_mahasiswa - jumlah_lulus << "\n";
    cout << "Rata-rata kelas  : "
         << total_nilai / jumlah_mahasiswa << "\n";

    return 0;
}
