
#include <iostream>
using namespace std;

int main() {
    int jumlah = 0;

    cout << "Jumlah nilai: ";
    cin >> jumlah;

    double total = 0;
    double nilai = 0;

    // Perulangan yang sengaja dibuat salah untuk praktikum debugger
    for (int i = 1; i <= jumlah; i++) {
        cout << "Nilai ke-" << i << ": ";
        cin >> nilai;

        total += nilai;
    }

    double rata_rata = total / jumlah;

    cout << "Rata-rata: " << rata_rata << "\n";

    return 0;
}
