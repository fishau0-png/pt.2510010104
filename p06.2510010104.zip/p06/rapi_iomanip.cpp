
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {
    string nama = "Siti Aminah";
    double nilai_akhir = 83.975;
    double rerata = 67.075;

    cout << "Tanpa pengaturan:\n";
    cout << nilai_akhir << " " << rerata
         << " " << 2.0 / 3 << "\n\n";

    cout << "Dua angka di belakang koma:\n";
    cout << fixed << setprecision(2);
    cout << nilai_akhir << " " << rerata
         << " " << 2.0 / 3 << "\n\n";

    cout << "Kolom selebar 20 dan 8:\n";
    cout << left << setw(20) << "Nama"
         << right << setw(8) << "Nilai" << "\n";

    cout << left << setw(20) << nama
         << right << setw(8) << nilai_akhir << "\n";

    cout << left << setw(20) << "Budi Santoso"
         << right << setw(8) << 67.75 << "\n";

    cout << left << setw(20) << "Muhammad Abdul Rahman Putra"
         << right << setw(8) << 90.50 << "\n";

    return 0;
}

