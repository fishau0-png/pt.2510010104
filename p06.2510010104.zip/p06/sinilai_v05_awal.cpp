
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {
    const int JUMLAH = 6;

    string nama[JUMLAH] = {
        "Siti Aminah",
        "Budi Santoso",
        "Rina Wati",
        "Dewi Lestari",
        "Eko Prasetyo",
        "Fajar Nugroho"
    };

    double komponen[JUMLAH][4] = {
        {100, 85.5, 78, 80},
        {80, 70, 65, 60},
        {60, 50, 40, 55},
        {90, 90, 90, 90},
        {75, 72, 70, 68},
        {30, 20, 35, 25}
    };

    double total_nilai = 0;
    int jumlah_lulus = 0;

    int jumlah_a = 0;
    int jumlah_b = 0;
    int jumlah_c = 0;
    int jumlah_d = 0;
    int jumlah_e = 0;

    double nilai_tertinggi = -1;
    string nama_tertinggi = "";

    cout << fixed << setprecision(2);

    cout << "=== DAFTAR NILAI MAHASISWA ===\n\n";

    cout << left
         << setw(22) << "Mahasiswa"
         << setw(30) << "Komponen"
         << right << setw(13) << "Nilai akhir"
         << setw(10) << "Huruf"
         << setw(16) << "Status" << "\n";

    cout << string(91, '-') << "\n";

    for (int i = 0; i < JUMLAH; i++) {
        double nilai_akhir =
            komponen[i][0] * 0.10 +
            komponen[i][1] * 0.45 +
            komponen[i][2] * 0.25 +
            komponen[i][3] * 0.20;

        string huruf_mutu;
        string status;

        if (nilai_akhir >= 80) {
            huruf_mutu = "A";
        } else if (nilai_akhir >= 70) {
            huruf_mutu = "B";
        } else if (nilai_akhir >= 65) {
            huruf_mutu = "C+";
        } else if (nilai_akhir >= 40) {
            huruf_mutu = "D";
        } else {
            huruf_mutu = "E";
        }

        bool lulus = nilai_akhir >= 60;

        if (lulus) {
            status = "Lulus";
            jumlah_lulus++;
        } else {
            status = "Belum lulus";
        }

        total_nilai += nilai_akhir;

        switch (huruf_mutu[0]) {
            case 'A':
                jumlah_a++;
                break;
            case 'B':
                jumlah_b++;
                break;
            case 'C':
                jumlah_c++;
                break;
            case 'D':
                jumlah_d++;
                break;
            case 'E':
                jumlah_e++;
                break;
        }

        if (nilai_akhir > nilai_tertinggi) {
            nilai_tertinggi = nilai_akhir;
            nama_tertinggi = nama[i];
        }

        cout << left << setw(22) << nama[i];

        cout << setw(30)
             << (to_string(komponen[i][0]) + ", " +
                 to_string(komponen[i][1]) + ", " +
                 to_string(komponen[i][2]) + ", " +
                 to_string(komponen[i][3]));

        cout << right << setw(13) << nilai_akhir
             << setw(10) << huruf_mutu
             << setw(16) << status << "\n";
    }

    cout << "\n=== Laporan Kelas ===\n";
    cout << "Jumlah mahasiswa : " << JUMLAH << "\n";
    cout << "Lulus             : " << jumlah_lulus << "\n";
    cout << "Belum lulus       : " << JUMLAH - jumlah_lulus << "\n";
    cout << "Rata-rata kelas   : " << total_nilai / JUMLAH << "\n";
    cout << "Tertinggi         : " << nama_tertinggi
         << " (" << nilai_tertinggi << ")\n";

    cout << "\nSebaran huruf mutu:\n";
    cout << "A | " << string(jumlah_a, '#') << " " << jumlah_a << "\n";
    cout << "B | " << string(jumlah_b, '#') << " " << jumlah_b << "\n";
    cout << "C | " << string(jumlah_c, '#') << " " << jumlah_c << "\n";
    cout << "D | " << string(jumlah_d, '#') << " " << jumlah_d << "\n";
    cout << "E | " << string(jumlah_e, '#') << " " << jumlah_e << "\n";

    return 0;
}
