#include <iostream>
using namespace std;

int main() {
    double nilai = 0;

    cout << "Nilai (0-100): ";
    cin >> nilai;

    while (cin.fail() || nilai < 1 || nilai > 10) {
        if (cin.fail()) {
            cin.clear();
            cout << "Itu bukan angka. ";
        } else {
            cout << "Harus 1 sampai 10. ";
        }

        cout << "Coba lagi: ";
        cin >> nilai;
    }

    cout << "Tersimpan: " << nilai << "\n";

    return 0;
}
