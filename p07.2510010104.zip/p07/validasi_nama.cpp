#include <iostream>
#include <string>
#include <cctype>
using namespace std;

int main() {
    string nama;
    bool sah = false;

    do {
        cout << "Nama: ";
        getline(cin, nama);

        int panjang = nama.length();
        bool ada_huruf = false;
        bool ada_angka = false;

        for (int i = 0; i < panjang; i++) {
            if (nama[i] != ' ') {
                ada_huruf = true;
            }

            if (isdigit(static_cast<unsigned char>(nama[i]))) {
                ada_angka = true;
            }
        }

    if (!ada_huruf) {
        cout << "Nama tidak boleh kosong.\n";
    } else if (ada_angka) {
        cout << "Nama tidak boleh mengandung angka.\n";
    } else if (panjang < 3) {
        cout << "Nama minimal harus 3 karakter.\n";
    } else {
        sah = true;
    }

    } while (!sah);

    cout << "Nama tersimpan: " << nama << "\n";

    return 0;
}
