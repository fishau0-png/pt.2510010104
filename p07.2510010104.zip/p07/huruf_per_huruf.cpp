#include <iostream>
#include <string>
#include <cctype>
using namespace std;

int main() {
    string nama;
    cout << "Nama lengkap: ";
    getline(cin, nama);

    int panjang = nama.length();
    int spasi = 0;
    int vokal = 0;
    int huruf_besar = 0;
    string terbalik;
    string kapital;

    for (int i = 0; i < panjang; i++) {
        char c = nama[i];

        if (isupper(static_cast<unsigned char>(c))) {
            huruf_besar++;
    }

        if (c == ' ') {
            spasi++;
        }

        char kecil = tolower(static_cast<unsigned char>(c));

        if (kecil == 'a' || kecil == 'i' ||
            kecil == 'u' || kecil == 'e' ||
            kecil == 'o') {
            vokal++;
        }

        terbalik = c + terbalik;
        kapital = kapital + static_cast<char>(
            toupper(static_cast<unsigned char>(c))
        );
    }

    cout << "\nPanjang nama : " << panjang << "\n";
    cout << "Banyak kata : " << spasi + 1 << "\n";
    cout << "Banyak vokal : " << vokal << "\n";
    cout << "Huruf kapital: " << kapital << "\n";
    cout << "Dibalik      : " << terbalik << "\n";
    cout << "Jumlah huruf besar: " << huruf_besar << "\n";

    return 0;
}