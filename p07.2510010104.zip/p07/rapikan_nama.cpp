#include <iostream>
#include <string>
#include <sstream>
#include <cctype>
using namespace std;

int main() {
    string nama;
    cout << "Masukkan nama: ";
    getline(cin, nama);

    stringstream ss(nama);
    string kata;
    string hasil;
    bool kata_pertama = true;

    while (ss >> kata) {
        for (int i = 0; i < static_cast<int>(kata.length()); i++) {
            if (i == 0) {
                kata[i] = static_cast<char>(
                    toupper(static_cast<unsigned char>(kata[i]))
                );
            } else {
                kata[i] = static_cast<char>(
                    tolower(static_cast<unsigned char>(kata[i]))
                );
            }
        }

        if (!kata_pertama) {
            hasil += " ";
        }

        hasil += kata;
        kata_pertama = false;
    }

    cout << "Nama setelah dirapikan: " << hasil << "\n";

    return 0;
}
