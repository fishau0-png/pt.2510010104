#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
using namespace std;

int main() {
    int jumlah_mahasiswa = 0;

    // TODO 1: Validasi jumlah mahasiswa
    cout << "Jumlah mahasiswa (paling sedikit 1): ";
    cin >> jumlah_mahasiswa;

    while (cin.fail() || jumlah_mahasiswa < 1) {
        cin.clear();
        cin.ignore(1000, '\n');

        cout << "Masukan tidak valid. Masukkan jumlah mahasiswa minimal 1: ";
        cin >> jumlah_mahasiswa;
    }

    cin.ignore(1000, '\n');

    int lulus = 0;
    int belum_lulus = 0;
    double total_nilai = 0;
    double nilai_tertinggi = -1;
    string nama_tertinggi;

    for (int i = 0; i < jumlah_mahasiswa; i++) {
        string nama;
        string npm;
        double kehadiran = 0;
        double mingguan = 0;
        double uts = 0;
        double uas = 0;
        double nilai_akhir = 0;
        string nilai_huruf;
        string status;

        cout << "\n--- Mahasiswa ke-" << i + 1
             << " dari " << jumlah_mahasiswa << " ---\n";

        // TODO 2: Validasi nama
        bool sah = false;

        do {
            cout << "Nama       : ";
            getline(cin, nama);

            bool ada_huruf = false;
            bool ada_angka = false;

            for (int k = 0; k < static_cast<int>(nama.length()); k++) {
                if (nama[k] != ' ') {
                    ada_huruf = true;
                }

                if (isdigit(static_cast<unsigned char>(nama[k]))) {
                    ada_angka = true;
                }
            }

            if (!ada_huruf) {
                cout << "Nama tidak boleh kosong.\n";
            } else if (ada_angka) {
                cout << "Nama tidak boleh mengandung angka.\n";
            } else if (nama.length() < 3) {
                cout << "Nama minimal harus 3 karakter.\n";
            } else {
                sah = true;
            }
        } while (!sah);

        // TODO 3: Merapikan nama
        bool awal_kata = true;

        for (int k = 0; k < static_cast<int>(nama.length()); k++) {
            if (nama[k] == ' ') {
                awal_kata = true;
            } else {
                if (awal_kata) {
                    nama[k] = static_cast<char>(
                        toupper(static_cast<unsigned char>(nama[k]))
                    );
                    awal_kata = false;
                } else {
                    nama[k] = static_cast<char>(
                        tolower(static_cast<unsigned char>(nama[k]))
                    );
                }
            }
        }

        cout << "NPM        : ";
        getline(cin, npm);

        // TODO 4: Validasi kehadiran
        cout << "Kehadiran  : ";
        cin >> kehadiran;

        while (cin.fail() || kehadiran < 0 || kehadiran > 100) {
            cin.clear();
            cin.ignore(1000, '\n');

            cout << "Harus angka 0 sampai 100. Kehadiran: ";
            cin >> kehadiran;
        }

        // TODO 5: Validasi nilai mingguan, UTS, dan UAS
        cout << "Mingguan   : ";
        cin >> mingguan;

        while (cin.fail() || mingguan < 0 || mingguan > 100) {
            cin.clear();
            cin.ignore(1000, '\n');

            cout << "Harus angka 0 sampai 100. Mingguan: ";
            cin >> mingguan;
        }

        cout << "UTS        : ";
        cin >> uts;

        while (cin.fail() || uts < 0 || uts > 100) {
            cin.clear();
            cin.ignore(1000, '\n');

            cout << "Harus angka 0 sampai 100. UTS: ";
            cin >> uts;
        }

        cout << "UAS        : ";
        cin >> uas;

        while (cin.fail() || uas < 0 || uas > 100) {
            cin.clear();
            cin.ignore(1000, '\n');

            cout << "Harus angka 0 sampai 100. UAS: ";
            cin >> uas;
        }

        cin.ignore(1000, '\n');

        // Perhitungan nilai akhir
        nilai_akhir =
            kehadiran * 0.10 +
            mingguan * 0.20 +
            uts * 0.30 +
            uas * 0.40;

        // Penentuan nilai huruf
        if (nilai_akhir >= 85) {
            nilai_huruf = "A";
        } else if (nilai_akhir >= 75) {
            nilai_huruf = "B";
        } else if (nilai_akhir >= 65) {
            nilai_huruf = "C";
        } else if (nilai_akhir >= 50) {
            nilai_huruf = "D";
        } else {
            nilai_huruf = "E";
        }

        // Penentuan status kelulusan
        if (nilai_akhir >= 60) {
            status = "Lulus";
            lulus++;
        } else {
            status = "Belum lulus";
            belum_lulus++;
        }

        total_nilai += nilai_akhir;

        if (nilai_akhir > nilai_tertinggi) {
            nilai_tertinggi = nilai_akhir;
            nama_tertinggi = nama;
        }

        // Hasil setiap mahasiswa
        cout << fixed << setprecision(2);
        cout << "\nNama tersimpan : " << nama << '\n';
        cout << "NPM            : " << npm << '\n';
        cout << "Nilai akhir    : " << nilai_akhir << '\n';
        cout << "Nilai huruf    : " << nilai_huruf << '\n';
        cout << "Status         : " << status << '\n';
    }

    // Laporan kelas
    cout << "\n=== Laporan Kelas ===\n";
    cout << "Jumlah mahasiswa : " << jumlah_mahasiswa << '\n';
    cout << "Lulus             : " << lulus << '\n';
    cout << "Belum lulus       : " << belum_lulus << '\n';
    cout << fixed << setprecision(2);
    cout << "Rata-rata kelas   : "
         << total_nilai / jumlah_mahasiswa << '\n';
    cout << "Tertinggi         : " << nama_tertinggi
         << " (" << nilai_tertinggi << ")\n";

    return 0;
}