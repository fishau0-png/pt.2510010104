#include <iostream>
#include <string>
using namespace std;

int main() {
    string nama;
    int angkatan;
    double nilai;

    cout << "Masukkan nama: ";
    getline(cin, nama);

    cout << "Masukkan angkatan: ";
    cin >> angkatan;

    cout << "Masukkan nilai: ";
    cin >> nilai;

    cout << "\nNama     : " << nama << endl;
    cout << "Angkatan : " << angkatan << endl;
    cout << "Nilai    : " << nilai << endl;

    return 0;
}
