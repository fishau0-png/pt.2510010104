#include <iostream>
#include <string>
using namespace std;

int main() {
    // TODO 1: deklarasikan variabel untuk nama dan NPM.
    // Nama bisa lebih dari satu kata. NPM adalah deretan angka yang tidak pernah
    // dihitung, dan bisa diawali 0, jadi pikirkan tipe yang tepat.
    string nama;
    string npm;

    // TODO 2: deklarasikan empat variabel nilai: kehadiran, mingguan, uts, uas.
    // Nilai bisa berisi pecahan seperti 85.5.
    double kehadiran, mingguan, uts, uas;

    cout << "=== SiNilai V0.1 ===\n";

    cout << "Nama : ";
    cin >> ws;
    getline(cin, nama);

    cout << "NPM : ";
    cin >> npm;

    cout << "Kehadiran : ";
    cin >> kehadiran;

    cout << "Mingguan : ";
    cin >> mingguan;

    cout << "UTS : ";
    cin >> uts;

    cout << "UAS : ";
    cin >> uas;

    cout << "\n--- Kartu Data Mahasiswa ---\n";

    cout << "Nama       : " << nama << "\n";
    cout << "NPM        : " << npm << "\n";
    cout << "Kehadiran  : " << kehadiran << "\n";
    cout << "Mingguan   : " << mingguan << "\n";
    cout << "UTS        : " << uts << "\n";
    cout << "UAS        : " << uas << "\n";

    return 0;
}