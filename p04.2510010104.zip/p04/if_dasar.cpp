#include <iostream>
using namespace std;

int main() {
    double nilai;

    cout << "Masukkan nilai: ";
    cin >> nilai;

    if (nilai <= 60) 
        cout << "Peringatan: belum lulus" << endl;
    cout << "Terima kasih" << endl;

    return 0;
}