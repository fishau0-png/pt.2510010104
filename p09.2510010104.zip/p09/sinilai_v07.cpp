
#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
using namespace std;

// PROTOTIPE SEMUA FUNGSI
int bacaJumlah();
string bacaNama();
double bacaKomponen(string label);

void bacaData(string& nama, string& npm,
              double& kehadiran, double& mingguan,
              double& uts, double& uas);

double hitungNilaiAkhir(double kehadiran,
                        double mingguan,
                        double uts,
                        double uas);

string hurufMutu(double nilai_akhir);

void cetakBaris(string nama, double nilai_akhir,
                string huruf, bool lulus);

void perbaruiPenghitung(string huruf,
                        int& jumlah_a, int& jumlah_b,
                        int& jumlah_c, int& jumlah_d,
                        int& jumlah_e);

void cetakSebaran(int jumlah_a, int jumlah_b,
                  int jumlah_c, int jumlah_d,
                  int jumlah_e);


// ===================================
// PROGRAM UTAMA
// ===================================
int main() {

    cout << "=== SiNilai v0.7 ===\n";

    int jumlah_mahasiswa = bacaJumlah();

    cout << fixed << setprecision(2);

    double total_nilai = 0;

    int jumlah_lulus = 0;

    int jumlah_a = 0;
    int jumlah_b = 0;
    int jumlah_c = 0;
    int jumlah_d = 0;
    int jumlah_e = 0;

    double nilai_tertinggi = -1;
    string nama_tertinggi;

    for (int i = 1; i <= jumlah_mahasiswa; i++) {

        string nama;
        string npm;

        double kehadiran = 0;
        double mingguan = 0;
        double uts = 0;
        double uas = 0;

        cout << "\n--- Mahasiswa ke-" << i
             << " dari " << jumlah_mahasiswa << " ---\n";

        bacaData(nama, npm, kehadiran,
                 mingguan, uts, uas);

        double nilai_akhir =
            hitungNilaiAkhir(kehadiran, mingguan, uts, uas);

        string huruf = hurufMutu(nilai_akhir);

        bool lulus = nilai_akhir >= 60;

        cetakBaris(nama, nilai_akhir, huruf, lulus);

        total_nilai += nilai_akhir;

        if (lulus) {
            jumlah_lulus++;
        }

        perbaruiPenghitung(huruf, jumlah_a, jumlah_b,
                           jumlah_c, jumlah_d, jumlah_e);

        if (nilai_akhir > nilai_tertinggi) {
            nilai_tertinggi = nilai_akhir;
            nama_tertinggi = nama;
        }
    }

    // LAPORAN KELAS
    cout << "\n=== Laporan Kelas ===\n";

    cout << "Jumlah mahasiswa : "
         << jumlah_mahasiswa << "\n";

    cout << "Lulus             : "
         << jumlah_lulus << "\n";

    cout << "Belum lulus       : "
         << jumlah_mahasiswa - jumlah_lulus << "\n";

    cout << "Rata-rata kelas   : "
         << total_nilai / jumlah_mahasiswa << "\n";

    cout << "Tertinggi         : "
         << nama_tertinggi << " ("
         << nilai_tertinggi << ")\n";

    cetakSebaran(jumlah_a, jumlah_b, jumlah_c,
                 jumlah_d, jumlah_e);

    return 0;
}


// ===================================
// FUNGSI BACA JUMLAH
// ===================================
int bacaJumlah() {

    int jumlah_mahasiswa = 0;

    cout << "Jumlah mahasiswa (paling sedikit 1): ";
    cin >> jumlah_mahasiswa;

    while (cin.fail() || jumlah_mahasiswa < 1) {

        cin.clear();
        cin.ignore(1000, '\n');

        cout << "Masukan tidak valid. "
             << "Masukkan jumlah mahasiswa minimal 1: ";

        cin >> jumlah_mahasiswa;
    }

    cin.ignore(1000, '\n');

    return jumlah_mahasiswa;
}


// ===================================
// TODO 1: BACA KOMPONEN
// ===================================
double bacaKomponen(string label) {

    double nilai = 0;

    cout << label << " : ";
    cin >> nilai;

    while (cin.fail() || nilai < 0 || nilai > 100) {

        cin.clear();
        cin.ignore(1000, '\n');

        cout << "Harus angka 0 sampai 100. "
             << label << " : ";

        cin >> nilai;
    }

    return nilai;
}


// ===================================
// TODO 2: BACA NAMA
// ===================================
string bacaNama() {

    string nama;
    bool sah = false;

    do {

        cout << "Nama       : ";
        getline(cin, nama);

        bool ada_huruf = false;
        bool ada_angka = false;

        for (int k = 0;
             k < static_cast<int>(nama.length()); k++) {

            if (nama[k] != ' ') {
                ada_huruf = true;
            }

            if (isdigit(static_cast<unsigned char>(nama[k]))) {
                ada_angka = true;
            }
        }

        if (!ada_huruf) {
            cout << "Nama tidak boleh kosong.\n";
        }
        else if (ada_angka) {
            cout << "Nama tidak boleh mengandung angka.\n";
        }
        else if (nama.length() < 3) {
            cout << "Nama minimal harus 3 karakter.\n";
        }
        else {
            sah = true;
        }

    } while (!sah);

    // Merapikan nama
    bool awal_kata = true;

    for (int k = 0;
         k < static_cast<int>(nama.length()); k++) {

        if (nama[k] == ' ') {
            awal_kata = true;
        }
        else {

            if (awal_kata) {

                nama[k] = static_cast<char>(
                    toupper(static_cast<unsigned char>(nama[k]))
                );

                awal_kata = false;
            }
            else {

                nama[k] = static_cast<char>(
                    tolower(static_cast<unsigned char>(nama[k]))
                );
            }
        }
    }

    return nama;
}


// ===================================
// TODO 3: BACA DATA
// ===================================
void bacaData(string& nama, string& npm,
              double& kehadiran, double& mingguan,
              double& uts, double& uas) {

    nama = bacaNama();

    cout << "NPM        : ";
    getline(cin, npm);

    kehadiran = bacaKomponen("Kehadiran");
    mingguan = bacaKomponen("Mingguan");
    uts = bacaKomponen("UTS");
    uas = bacaKomponen("UAS");

    cin.ignore(1000, '\n');
}


// ===================================
// FUNGSI HITUNG NILAI AKHIR
// ===================================
double hitungNilaiAkhir(double kehadiran,
                        double mingguan,
                        double uts,
                        double uas) {

    return kehadiran * 0.10 +
           mingguan * 0.20 +
           uts * 0.30 +
           uas * 0.40;
}


// ===================================
// TODO 4: HURUF MUTU
// ===================================
string hurufMutu(double nilai_akhir) {

    if (nilai_akhir >= 85) {
        return "A";
    }
    else if (nilai_akhir >= 75) {
        return "B";
    }
    else if (nilai_akhir >= 65) {
        return "C";
    }
    else if (nilai_akhir >= 50) {
        return "D";
    }
    else {
        return "E";
    }
}


// ===================================
// FUNGSI CETAK HASIL
// ===================================
void cetakBaris(string nama, double nilai_akhir,
                string huruf, bool lulus) {

    cout << "\nNama tersimpan : " << nama << "\n";
    cout << "Nilai akhir    : " << nilai_akhir << "\n";
    cout << "Nilai huruf    : " << huruf << "\n";

    cout << "Status         : ";

    if (lulus) {
        cout << "Lulus\n";
    }
    else {
        cout << "Belum lulus\n";
    }
}


// ===================================
// TODO 5: PERBARUI PENGHITUNG
// ===================================
void perbaruiPenghitung(string huruf,
                        int& jumlah_a, int& jumlah_b,
                        int& jumlah_c, int& jumlah_d,
                        int& jumlah_e) {

    switch (huruf[0]) {

        case 'A':
            jumlah_a++;
            break;

        case 'B':
            jumlah_b++;
            break;

        case 'C':
            jumlah_c++;
            break;

        case 'D':
            jumlah_d++;
            break;

        case 'E':
            jumlah_e++;
            break;
    }
}


// ===================================
// TODO 6: CETAK SEBARAN
// ===================================
void cetakSebaran(int jumlah_a, int jumlah_b,
                  int jumlah_c, int jumlah_d,
                  int jumlah_e) {

    cout << "\n=== Sebaran Nilai ===\n";

    string huruf[] = {"A", "B", "C", "D", "E"};

    int jumlah[] = {
        jumlah_a,
        jumlah_b,
        jumlah_c,
        jumlah_d,
        jumlah_e
    };

    for (int i = 0; i < 5; i++) {

        cout << huruf[i] << " : ";

        for (int j = 0; j < jumlah[i]; j++) {
            cout << "*";
        }

        cout << " (" << jumlah[i] << ")\n";
    }
}
