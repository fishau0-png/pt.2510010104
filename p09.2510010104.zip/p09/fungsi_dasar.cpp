
#include <iostream>
using namespace std;

// PROTOTIPE FUNGSI
double hitungNilaiAkhir(double kehadiran, double mingguan,
                        double uts, double uas);

void cetakGaris(int panjang);

double rerataDua(double a, double b);

int main() {

    cout << "PROGRAM MENGHITUNG NILAI AKHIR" << endl;

    cetakGaris(30);

    cout << "Siti : "
         << hitungNilaiAkhir(100, 85.5, 78, 80) << endl;

    cout << "Budi : "
         << hitungNilaiAkhir(80, 70, 65, 60) << endl;

    double nilai_rina =
        hitungNilaiAkhir(60, 50, 40, 55);

    cout << "Rina : " << nilai_rina << endl;

    cetakGaris(30);

    cout << "Rata-rata 75 dan 80 = "
         << rerataDua(75, 80) << endl;

    cetakGaris(30);

    return 0;
}

// DEFINISI FUNGSI HITUNG NILAI AKHIR
double hitungNilaiAkhir(double kehadiran, double mingguan,
                        double uts, double uas) {

    const double BOBOT_KEHADIRAN = 0.10;
    const double BOBOT_MINGGUAN = 0.45;
    const double BOBOT_UTS = 0.25;
    const double BOBOT_UAS = 0.20;

    double hasil =
        kehadiran * BOBOT_KEHADIRAN +
        mingguan * BOBOT_MINGGUAN +
        uts * BOBOT_UTS +
        uas * BOBOT_UAS;

    return hasil;
}

// DEFINISI FUNGSI CETAK GARIS
void cetakGaris(int panjang) {

    for (int i = 1; i <= panjang; i++) {
        cout << "-";
    }

    cout << endl;
}

// DEFINISI FUNGSI RERATA DUA
double rerataDua(double a, double b) {

    return (a + b) / 2;
}
