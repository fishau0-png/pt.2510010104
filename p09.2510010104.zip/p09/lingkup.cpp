
#include <iostream>
using namespace std;

// VARIABEL GLOBAL
int banyak_panggilan = 0;

// PROTOTIPE FUNGSI
int kuadrat(int n);
void catat(int& banyak);
void cetakDuaKali();

int main() {

    // Variabel lokal milik main
    int n = 5;

    cout << "kuadrat(" << n << ") = "
         << kuadrat(n) << "\n";

    cout << "n di main tetap " << n << "\n";

    // Memanggil fungsi catat
    catat(banyak_panggilan);
    catat(banyak_panggilan);

    // Memanggil fungsi cetakDuaKali
    cetakDuaKali();

    cout << "banyak_panggilan = "
         << banyak_panggilan
         << " (siapa saja yang mengubahnya?)\n";

    return 0;
}

// FUNGSI KUADRAT
int kuadrat(int n) {
    n = n * n;
    return n;
}

// FUNGSI CATAT
void catat(int& banyak) {

    int hitung = 0;

    hitung++;
    banyak++;

    cout << "catat: hitung = " << hitung
         << ", banyak_panggilan = "
         << banyak << "\n";
}

// FUNGSI CETAK DUA KALI
void cetakDuaKali() {

    banyak_panggilan += 2;

    cout << "cetakDuaKali dipanggil\n";
}
