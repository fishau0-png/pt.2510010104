
#include <iostream>
#include <string>
#include <limits>
#include <cctype>
using namespace std;

// BATAS NILAI
const double BATAS_BAWAH = 0;
const double BATAS_ATAS = 200;

// PROTOTIPE FUNGSI
string bacaNama();
double bacaKomponen(string label);
int bacaBulat(string label, int batas_bawah, int batas_atas);

int main() {

    cout << "==================================" << endl;
    cout << "       PROGRAM NILAI MAHASISWA" << endl;
    cout << "==================================" << endl;

    // Membaca nama mahasiswa
    string nama = bacaNama();

    // Membaca empat komponen nilai
    double kehadiran = bacaKomponen("Kehadiran");
    double mingguan = bacaKomponen("Mingguan");
    double uts = bacaKomponen("UTS");
    double uas = bacaKomponen("UAS");

    // Membaca jumlah mahasiswa
    int jumlah = bacaBulat("Jumlah mahasiswa", 1, 200);

    // Menampilkan hasil
    cout << "\n==================================" << endl;
    cout << "          HASIL INPUT" << endl;
    cout << "==================================" << endl;

    cout << "Nama       : " << nama << endl;
    cout << "Kehadiran  : " << kehadiran << endl;
    cout << "Mingguan   : " << mingguan << endl;
    cout << "UTS        : " << uts << endl;
    cout << "UAS        : " << uas << endl;
    cout << "Jumlah     : " << jumlah << endl;

    cout << "==================================" << endl;

    return 0;
}

// FUNGSI MEMBACA NAMA
string bacaNama() {

    string nama;

    while (true) {

        cout << "Masukkan nama: ";
        getline(cin, nama);

        bool valid = !nama.empty();

        for (char c : nama) {
            if (!isalpha(static_cast<unsigned char>(c))
                && c != ' ') {
                valid = false;
                break;
            }
        }

        if (valid) {
            return nama;
        }

        cout << "Nama tidak valid! Masukkan huruf saja.\n";
    }
}

// FUNGSI MEMBACA KOMPONEN
double bacaKomponen(string label) {

    double nilai;

    while (true) {

        cout << label << " (0-"
             << BATAS_ATAS << "): ";

        cin >> nilai;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Input harus berupa angka!\n";
            continue;
        }

        if (nilai < BATAS_BAWAH ||
            nilai > BATAS_ATAS) {

            cout << "Nilai harus antara 0 sampai "
                 << BATAS_ATAS << "!\n";
            continue;
        }

        return nilai;
    }
}

// FUNGSI MEMBACA BILANGAN BULAT
int bacaBulat(string label, int batas_bawah,
              int batas_atas) {

    int nilai;

    while (true) {

        cout << label << " ("
             << batas_bawah << "-"
             << batas_atas << "): ";

        cin >> nilai;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Input harus berupa bilangan bulat!\n";
            continue;
        }

        if (nilai < batas_bawah ||
            nilai > batas_atas) {

            cout << "Angka harus antara "
                 << batas_bawah << " sampai "
                 << batas_atas << "!\n";
            continue;
        }

        return nilai;
    }
}
