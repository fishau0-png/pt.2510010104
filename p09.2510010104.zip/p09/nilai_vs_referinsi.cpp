
#include <iostream>
using namespace std;

// PROTOTIPE FUNGSI
void tambahSatuSalinan(int x);
void tambahSatuAsli(int& x);
void tukar(int& a, int& b);
void bagiDua(int total, int& hasil, int& sisa);

int main() {

    // LANGKAH 1: SALINAN DAN REFERENSI
    int umur = 19;

    cout << "NILAI AWAL UMUR = " << umur << endl;

    tambahSatuSalinan(umur);
    cout << "Setelah tambahSatuSalinan : "
         << umur << endl;

    tambahSatuAsli(umur);
    cout << "Setelah tambahSatuAsli    : "
         << umur << endl;

    cout << endl;

    // LANGKAH 2 DAN 3: TUKAR NILAI
    int p = 3;
    int q = 8;

    cout << "Sebelum tukar : p = " << p
         << ", q = " << q << endl;

    tukar(p, q);

    cout << "Setelah tukar : p = " << p
         << ", q = " << q << endl;

    cout << endl;

    // LANGKAH 4: FUNGSI BAGI DUA
    int total = 17;
    int hasil = 0;
    int sisa = 0;

    bagiDua(total, hasil, sisa);

    cout << "Total = " << total << endl;
    cout << "Hasil = " << hasil << endl;
    cout << "Sisa  = " << sisa << endl;

    return 0;
}

// FUNGSI SALINAN
void tambahSatuSalinan(int x) {
    x = x + 1;
    cout << "Di dalam salinan : " << x << endl;
}

// FUNGSI REFERENSI
void tambahSatuAsli(int& x) {
    x = x + 1;
    cout << "Di dalam referensi : " << x << endl;
}

// FUNGSI TUKAR
void tukar(int& a, int& b) {
    int sementara = a;
    a = b;
    b = sementara;
}

// FUNGSI BAGI DUA
void bagiDua(int total, int& hasil, int& sisa) {
    hasil = total / 2;
    sisa = total % 2;
}
