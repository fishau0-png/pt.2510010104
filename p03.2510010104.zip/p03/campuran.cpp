#include <iostream>
using namespace std;

int main() {
    int uts = 75;
    int uas = 80;

    // Rata-rata pertama
    double rerata_1 = (uts + uas) / 2;
    cout << "Rerata 1 = " << rerata_1 << endl;

    // Rata-rata dengan data double
    double uts2 = 75;
    double uas2 = 80;

    double rerata_2 = (uts2 + uas2) / 2;
    cout << "Rerata 2 = " << rerata_2 << endl;

    // Menggunakan 2.0 agar pembagian pasti pecahan
    double rerata_3 = (uts + uas) / 2.0;
    cout << "Rerata 3 = " << rerata_3 << endl;

    return 0;
}